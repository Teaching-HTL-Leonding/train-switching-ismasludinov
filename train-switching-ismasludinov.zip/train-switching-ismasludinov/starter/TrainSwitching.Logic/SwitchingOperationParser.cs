namespace TrainSwitching.Logic;

public static class SwitchingOperationParser
{
    /// <summary>
    /// Parses a line of input into a <see cref="SwitchingOperation"/>.
    /// </summary>
    /// <param name="inputLine">Line to parse. See readme.md for details</param>
    /// <returns>The parsed switching operation</returns>
    public static SwitchingOperation Parse(string inputLine)
    {
        var result = new SwitchingOperation();

        string[] splitted = inputLine.Split(',');
        string[] splittedfirst = splitted[0].Split(' ');
        result.TrackNumber = Convert.ToInt32(splittedfirst[2]);
        string[] splittedsecond = splitted[1].Split(" ");
       
        //Operation of Wagon
        if (splittedsecond.Contains("leaves")) 
        {
          result.OperationType = 0;
        }
        else if(splittedsecond.Contains("add"))
        {
          result.OperationType = 1;
        }
        else if(splittedsecond.Contains("remove"))
        {
           result.OperationType = -1;
           result.NumberOfWagons = Convert.ToInt32(splittedsecond[2]);  
        }

        //TypeOfWagon
        if (splittedsecond.Contains("Passenger"))
        {
           result.WagonType = 0;
        }
        else if (splittedsecond.Contains("Locomotive"))
        {
           result.WagonType = 1;
        }
        else if (splittedsecond.Contains("Freight"))
        {
           result.WagonType = 2;
        }
        else if (splittedsecond.Contains("Car"))
        {
            result.WagonType = 3;
        }

        //Direction
        if(splittedsecond.Contains("East"))
        {
          result.Direction = 0;
        }
        else if (splittedsecond.Contains("West"))
        {
          result.Direction = 1;
        }


        return result;
  }
}
