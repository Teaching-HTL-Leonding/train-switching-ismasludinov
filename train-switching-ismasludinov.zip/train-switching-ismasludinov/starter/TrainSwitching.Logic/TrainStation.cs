namespace TrainSwitching.Logic;

public class TrainStation
{
  public Track[] Tracks { get; }

  public TrainStation()
  {

    Tracks = new Track[10];
    for (int i = 0; i < 10; i++)
    {
      Tracks[i] = new Track();
    }
  }

  /// <summary>
  /// Tries to apply the given operation to the train station.
  /// </summary>
  /// <param name="op">Operation to apply</param>
  /// <returns>Returns true if the operation could be applied, otherwise false</returns>
  public bool TryApplyOperation(SwitchingOperation op)
  {
    if (op.OperationType == -1 && op.NumberOfWagons > Tracks[op.TrackNumber].Wagons.Count)
    {
      return false;
    }
    else if ((op.OperationType == -1 || op.OperationType == 1) && (op.Direction != 0 || op.Direction != 1))
    {
      return false;
    }
    else if (op.OperationType == 0 && op.Direction != 0 || op.Direction != 1)
    {
      return false;
    }
    else if (op.OperationType == 0 && op.WagonType != 1)
    {
      return false;
    }
    else if (op.OperationType == 0 && Tracks[op.TrackNumber].Wagons.Count == 0)
    {
      return false;
    }
    else return true;
  }

  /// <summary>
  /// Calculates the checksum of the train station.
  /// </summary>
  /// <returns>The calculated checksum</returns>
  /// <remarks>
  /// See readme.md for details on how to calculate the checksum.
  /// </remarks>

  public int CalculateChecksum()
  {
    int checksum = 0;

    for (int i = 0; i < 10; i++)
    {
      var track = Tracks[i];
      int trackValue = 0;
      foreach (var wagon in track.Wagons)
      {
        switch (wagon)
        {
          case Constants.WAGON_TYPE_PASSENGER:
            trackValue += 1;
            break;
          case Constants.WAGON_TYPE_LOCOMOTIVE:
            trackValue += 10;
            break;
          case Constants.WAGON_TYPE_FREIGHT:
            trackValue += 20;
            break;
          case Constants.WAGON_TYPE_CAR_TRANSPORT:
            trackValue += 30;
            break;
        }
      }
      checksum += trackValue * (i + 1); 
    }

    return checksum;
  }
}
